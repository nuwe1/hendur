<!DOCTYPE HTML>
<head>
<title>Hendur| About</title>
<meta charset="utf-8">
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/menu/css/simple_menu.css">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/css/gridNavigation.css">
<!--JS FILES -->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.mousewheel.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.gridnav.js"></script>
<script src="<?= base_url(); ?>assets/js/easing/jquery.easing.1.3.js"></script>
<script>
$(function () {
    $('#tj_container').gridnav({
        type: {
            mode: 'seqfade', // use def | fade | seqfade | updown | sequpdown | showhide | disperse | rows
            speed: 500, // for fade, seqfade, updown, sequpdown, showhide, disperse, rows
            easing: '', // for fade, seqfade, updown, sequpdown, showhide, disperse, rows	
            factor: 100, // for seqfade, sequpdown, rows
            reverse: '' // for sequpdown
        }
    });
});
</script>
</head>
<body>
<div class="header">
  <!-- Logo/Title -->
  <div id="site_title"><a href="index.html"> <img src="<?= base_url(); ?>assets/img/logo.png" alt=""></a> </div>
  <!-- Main Menu -->
  <ol id="menu">
    <li><a href="<?=site_url('Welcome/home');?>">Home</a>
      
    </li>
    <li><a href="<?=site_url('Welcome/blog');?>">Blog</a>
    </li>
    <li><a href="<?=site_url('Welcome/about');?>">About</a>   
    </li>
    <li><a href="<?=site_url('Welcome/sponsor');?>">Sponsors</a>   
    </li>
    <li><a href="<?=site_url('Welcome/product');?>">Products</a>   
    </li>
    <li><a href="<?=site_url('Welcome/contact');?>">Contact</a>   
    </li>
    
  </ol>
</div>
<!-- END header -->
<div id="container">
  <div id="grid">
    <div class="one-third">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Lorem Ipsum</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.Eis ad suis Tyrium coniugem in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img class="portfolio-item" src="<?= base_url(); ?>assets/img/photo_grid/grid-img-01.jpg" alt="" width="318" height="150"></div>
    </div>
    <div class="one-third">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.Eis ad suis Tyrium coniugem in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img class="portfolio-item" src="<?= base_url(); ?>assets/img/photo_grid/grid-img-02.jpg" alt="" width="318" height="150"></div>
    </div>
    <div class="one-third last-grid">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.Eis ad suis Tyrium coniugem in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img class="portfolio-item" src="<?= base_url(); ?>assets/img/photo_grid/grid-img-03.jpg" alt="" width="318" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-04.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-05.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-06.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="img/photo_grid/grid-img-07.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-08.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fourth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-09.jpg" alt="" width="238" height="150"></div>
    </div>
    <div class="one-fifth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Mini Block</h4>
            <p>Decollari rediit in modo ad quia.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-10.jpg" alt="" width="118" height="150"></div>
    </div>
    <div class="one-fifth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Mini Block</h4>
            <p>Decollari rediit in modo ad quia.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-11.jpg" alt="" width="118" height="150"></div>
    </div>
    <div class="one-fifth">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Mini Block</h4>
            <p>Decollari rediit in modo ad quia.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-12.jpg" alt="" width="118" height="150"></div>
    </div>
    <div class="one-fifth last-grid">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Mini Block</h4>
            <p>Decollari rediit in modo ad quia.</p>
            <a href="#">Read More</a></div>
        </div>
        <img src="<?= base_url(); ?>assets/img/photo_grid/grid-img-13.jpg" alt="" width="118" height="150"></div>
    </div>
    <div class="one-half">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.Eis ad suis Tyrium coniugem in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img class="portfolio-item" src="<?= base_url(); ?>assets/img/photo_grid/grid-img-17.jpg" alt="" width="478" height="150"></div>
    </div>
    <div class="one-half last-grid">
      <div class="item-hover">
        <div class="portfolio-thumbnail">
          <div class="thumb-text">
            <h4>Dummy Text</h4>
            <p>Decollari rediit in modo ad quia. Potius aureos mercatoris vidisset spectacula tolli in lucem.Eis ad suis Tyrium coniugem in lucem.</p>
            <a href="#">Read More</a></div>
        </div>
        <img class="portfolio-item" src="<?= base_url(); ?>assets/img/photo_grid/grid-img-18.jpg" alt="" width="478" height="150"></div>
    </div>
  </div>
  <div style="clear:both; height: 40px"></div>
</div>
<!-- END container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
    <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
      Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="<?= base_url(); ?>assets/img/icon_fb.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_twitter.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>