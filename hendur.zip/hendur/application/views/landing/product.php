<!DOCTYPE HTML>
<head>
<title>Bigshot | EI Slider</title>
<meta charset="utf-8">
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/menu/css/simple_menu.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/nivo-slider.css" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/boxes/css/style5.css">
<!-- JS Files -->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/jquery.eislideshow.js"></script>
<script src="<?= base_url(); ?>assets/js/custom.js"></script>
<script>
jQuery.noConflict()(function ($) {
    $('#ei-slider').eislideshow({
        animation: 'center',
        autoplay: true,
        slideshow_interval: 3000,
        titlesFactor: 0
    });
});
</script>
<script src="<?= base_url(); ?>assets/js/slides/slides.min.jquery.js"></script>
<script src="<?= base_url(); ?>assets/js/cycle-slider/cycle.js"></script>
<script src="<?= base_url(); ?>assets/js/nivo-slider/jquery.nivo.slider.js"></script>
<script src="<?= base_url(); ?>assets/js/tabify/jquery.tabify.js"></script>
<script src="<?= base_url(); ?>assets/js/prettyPhoto/jquery.prettyPhoto.js"></script>
<script src="<?= base_url(); ?>assets/js/twitter/jquery.tweet.js"></script>
<script src="<?= base_url(); ?>assets/js/scrolltop/scrolltopcontrol.js"></script>
<script src="<?= base_url(); ?>assets/js/portfolio/filterable.js"></script>
<script src="<?= base_url(); ?>assets/js/modernizr/modernizr-2.0.3.js"></script>
<script src="<?= base_url(); ?>assets/js/easing/jquery.easing.1.3.js"></script>
<script src="<?= base_url(); ?>assets/js/kwicks/jquery.kwicks-1.5.1.pack.js"></script>
<script src="<?= base_url(); ?>assets/js/swfobject/swfobject.js"></script>
<!-- FancyBox -->
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox.css" media="all">
<script src="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox-1.2.1.js"></script>
</head>
<body style="background: #FFF">
<div style="width:100%; background: #FFF">
  <div class="header">
    <!-- Logo/Title -->
    <div id="site_title"><a href="index.html"> <img src="<?= base_url(); ?>assets/img/logo.png" alt=""></a> </div>
    <!-- Main Menu -->
     <ol id="menu">
    <li><a href="<?=site_url('Welcome/home');?>">Home</a>
      
    </li>
    <li><a href="<?=site_url('Welcome/blog');?>">Blog</a>
    </li>
    <li><a href="<?=site_url('Welcome/about');?>">About</a>   
    </li>
    <li><a href="<?=site_url('Welcome/sponsor');?>">Sponsors</a>   
    </li>
    <li><a href="<?=site_url('Welcome/product');?>">Products</a>   
    </li>
    <li><a href="<?=site_url('Welcome/contact');?>">Contact</a>   
    </li>
    
  </ol>
  </div>
  <!-- END header -->
</div>
<div class="wrapper">
  <div id="ei-slider" class="ei-slider">
    <ul class="ei-slider-large">
      <li> <img src="<?= base_url(); ?>assets/img/large/1.jpg" alt="">
        <div class="ei-title">
          <h2>Professional</h2>
          <h3>Lightning Equipment</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/2.jpg" alt="">
        <div class="ei-title">
          <h2>Passionate</h2>
          <h3>Ballerina</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/3.jpg" alt="">
        <div class="ei-title">
          <h2>Tranquility</h2>
          <h3>in red</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/4.jpg" alt="">
        <div class="ei-title">
          <h2>Vintage</h2>
          <h3>Beauty</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/5.jpg" alt="">
        <div class="ei-title">
          <h2>Mystery</h2>
          <h3>Woman</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/6.jpg" alt="">
        <div class="ei-title">
          <h2>In the</h2>
          <h3>Spotlight</h3>
        </div>
      </li>
      <li> <img src="<?= base_url(); ?>assets/img/large/7.jpg" alt="">
        <div class="ei-title">
          <h2>A touch of</h2>
          <h3>Fashion</h3>
        </div>
      </li>
    </ul>
    <!-- ei-slider-large -->
    <ul class="ei-slider-thumbs">
      <li class="ei-slider-element">Current</li>
      <li><a href="#">Slide 1</a><img src="<?= base_url(); ?>assets/img/thumbs/1.jpg" alt=""></li>
      <li><a href="#">Slide 2</a><img src="<?= base_url(); ?>assets/img/thumbs/2.jpg" alt=""></li>
      <li><a href="#">Slide 3</a><img src="<?= base_url(); ?>assets/img/thumbs/3.jpg" alt=""></li>
      <li><a href="#">Slide 4</a><img src="<?= base_url(); ?>assets/img/thumbs/4.jpg" alt=""></li>
      <li><a href="#">Slide 5</a><img src="<?= base_url(); ?>assets/img/thumbs/5.jpg" alt=""></li>
      <li><a href="#">Slide 6</a><img src="<?= base_url(); ?>assets/img/thumbs/6.jpg" alt=""></li>
      <li><a href="#">Slide 7</a><img src="<?= base_url(); ?>assets/img/thumbs/7.jpg" alt=""></li>
    </ul>
    <!-- ei-slider-thumbs -->
  </div>
  <!-- ei-slider -->
</div>
<!-- wrapper -->
<div id="container">
  <ul class="ca-menu" style="margin: 40px 0">
    <li> <a href="#"> <span class="ca-icon">A</span>
      <div class="ca-content">
        <h2 class="ca-main">Exceptional Service</h2>
        <h3 class="ca-sub">Personalized to your needs</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">I</span>
      <div class="ca-content">
        <h2 class="ca-main">Creative Storytelling</h2>
        <h3 class="ca-sub">Advanced use of technology</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">C</span>
      <div class="ca-content">
        <h2 class="ca-main">Infographical Education</h2>
        <h3 class="ca-sub">Understanding visually</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">S</span>
      <div class="ca-content">
        <h2 class="ca-main">Sophisticated Team</h2>
        <h3 class="ca-sub">Professionals in action</h3>
      </div>
      </a> </li>
  </ul>
  <div style="clear:both; height: 40px"></div>
  <div class="box_highlight">
    <h1 style="font-size:28px; letter-spacing: 16px; padding-top: 20px; text-align:center; text-transform: uppercase; color: #a7a7a7"> The beauty of simplicity</h1>
  </div>
  <div style="clear:both; height: 40px"></div>
</div>
<!-- END container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
    <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
      Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="<?= base_url(); ?>assets/img/icon_fb.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_twitter.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>