<!DOCTYPE HTML>
<head>
<title>Hendur| Welcome</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/menu/css/simple_menu.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/nivo-slider.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/supersized.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?= base_url(); ?>assets/theme/supersized.shutter.css" type="text/css" media="screen">
<!-- Google fonts -->
<link href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300|Playfair+Display:400italic' rel='stylesheet' type='text/css' />
<!--JS FILES STARTS-->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/easing/jquery.easing.1.3.js"></script>
<script src="<?= base_url(); ?>assets/js/supersized.3.2.6.min.js"></script>
<script src="<?= base_url(); ?>assets/theme/supersized.shutter.min.js"></script>
<script>
/***************************************************
SUPER SIZED
***************************************************/
jQuery.noConflict()(function ($) {
    $.supersized({
        // Functionality
        slide_interval: 3000, // Length between transitions
        transition: 1, // 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
        transition_speed: 700, // Speed of transition
        // Components             
        slide_links: 'blank', // Individual links for each slide (Options: false, 'num', 'name', 'blank')
        slides:
        // Slideshow Images
        [{
            image: '<?= base_url(); ?>assets/img/demo/full1.jpg',
            title: 'This is a welcome mesage with logo short video and quote for chose you campaign',
            thumb: 'slideshow/slide_1.jpg',
            url: '#'
        }, {
            image: '<?= base_url(); ?>assets/img/demo/full2.jpg',
            title: 'this is a slide with quotes because this is page with quotes that support choose you campain',
            thumb: 'slideshow/slide_2.jpg',
            url: '#'
        }, {
            image: '<?= base_url(); ?>assets/img/demo/full3.jpg',
            title: 'Add photo of famous people with quotes already there',
            thumb: 'slideshow/slide_3.jpg',
            url: '#'
        }]
    });
});
</script>
</head>
<body>
<div class="header" style="background: rgb(255, 255, 255) ; opacity: 0.6; width: 96%; padding: 0 2%">
  <!-- Logo/Title -->
  <div id="site_title"  style="top: 60px"><img src="<?= base_url(); ?>assets/img/logo.png" alt=""><a href="<?=site_url('Welcome/home');?>" style="color:white;font-weight:bold;font-size:20px;"> Proceed</a> </div>
  <!-- Main Menu -->
  <!-- <ol id="menu">
    <li><a href="index.html">Home</a>-->
      <!-- sub menu -->
     <!--  <ol>
        <li><a href="nivo.html">Nivo Slider</a></li>
        <li><a href="ei-slider.html">EI Slider</a></li>
        <li><a href="fullscreen-gallery.html">Fullscreen Slider</a></li>
        <li><a href="image-frontpage.html">Static Image</a></li>
      </ol>
    </li>-->
    <!-- end sub menu -->
    <!-- <li><a href="#">Pages</a>-->
      <!-- sub menu -->
     <!--  <ol>
        <li><a href="magazine.html">Magazine</a></li>
        <li><a href="blog.html">Blog</a></li>
        <li><a href="full-width.html">Full Width Page</a></li>
        <li><a href="columns.html">Columns</a></li>
      </ol>
    </li>-->
    <!-- end sub menu -->
   <!--  <li><a href="elements.html">Elements</a></li>
    <li><a href="#">Galleries</a>-->
      <!-- sub menu -->
      <!-- <ol>
        <li><a href="gallery-simple.html">Simple</a></li>
        <li><a href="portfolio.html">Filterable</a></li>
        <li><a href="gallery-fader.html">Fade Scroll</a></li>
        <li><a href="video.html">Video</a></li>
        <li class="last"><a href="photogrid.html">PhotoGrid</a></li>
      </ol>
    </li>-->
    <!-- end sub menu -->
    <!-- <li><a href="contact.html">Contact</a></li>
  </ol> -->
</div>
<!-- END header -->
<!--Thumbnail Navigation-->
<div id="prevthumb"></div>
<div id="nextthumb"></div>
<!--Arrow Navigation-->
<a id="prevslide" class="load-item"></a> <a id="nextslide" class="load-item"></a>
<div id="thumb-tray" class="load-item">
  <div id="thumb-back"></div>
  <div id="thumb-forward"></div>
</div>
<!--Time Bar-->
<div id="progress-back" class="load-item">
  <div id="progress-bar"></div>
</div>
<!--Control Bar-->
<div id="controls-wrapper" class="load-item">
  <div id="controls"> <a id="play-button"><img src="<?= base_url(); ?>assets/img/pause.png" alt="" id="pauseplay"></a>
    <!--Slide counter-->
    <div id="slidecounter"> <span class="slidenumber"></span> / <span class="totalslides"></span> </div>
    <!--Slide captions displayed here-->
    <div id="slidecaption"></div>
    <!--Thumb Tray button-->
    <a id="tray-button"><img src="<?= base_url(); ?>assets/img/button-tray-up.png" alt="" id="tray-arrow"></a>
    <!--Navigation-->
    <ul id="slide-list">
    </ul>
  </div>
</div>
</body>
</html>
