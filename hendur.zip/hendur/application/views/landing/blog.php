<!DOCTYPE HTML>
<head>
<title>Hendur | Blog</title>
<meta charset="utf-8">
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/menu/css/simple_menu.css">
<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" media="screen">
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/boxes/css/style6.css">
<!-- JS Files -->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/custom.js"></script>
<script src="<?= base_url(); ?>assets/js/slides/slides.min.jquery.js"></script>
<script src="<?= base_url(); ?>assets/js/cycle-slider/cycle.js"></script>
<script src="<?= base_url(); ?>assets/js/nivo-slider/jquery.nivo.slider.js"></script>
<script src="<?= base_url(); ?>assets/js/tabify/jquery.tabify.js"></script>
<script src="<?= base_url(); ?>assets/js/prettyPhoto/jquery.prettyPhoto.js"></script>
<script src="<?= base_url(); ?>assets/js/twitter/jquery.tweet.js"></script>
<script src="<?= base_url(); ?>assets/js/scrolltop/scrolltopcontrol.js"></script>
<script src="<?= base_url(); ?>assets/js/portfolio/filterable.js"></script>
<script src="<?= base_url(); ?>assets/js/modernizr/modernizr-2.0.3.js"></script>
<script src="<?= base_url(); ?>assets/js/easing/jquery.easing.1.3.js"></script>
<script src="<?= base_url(); ?>assets/js/kwicks/jquery.kwicks-1.5.1.pack.js"></script>
<script src="<?= base_url(); ?>assets/js/swfobject/swfobject.js"></script>
<!-- FancyBox -->
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox.css" media="all">
<script src="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox-1.2.1.js"></script>
</head>
<body>
<div class="header">
  <!-- Logo/Title -->
  <div id="site_title"><a href="index.html"> <img src="<?= base_url(); ?>assets/img/logo.png" alt=""></a> </div>
  <!-- Main Menu -->
  <ol id="menu">
    <li><a href="<?=site_url('Welcome/home');?>">Home</a>
      
    </li>
    <li><a href="<?=site_url('Welcome/blog');?>">Blog</a>
    </li>
    <li><a href="<?=site_url('Welcome/about');?>">About</a>   
    </li>
    <li><a href="<?=site_url('Welcome/sponsor');?>">Sponsors</a>   
    </li>
    <li><a href="<?=site_url('Welcome/product');?>">Products</a>   
    </li>
    <li><a href="<?=site_url('Welcome/contact');?>">Contact</a>   
    </li>
    
  </ol>
</div>
<!-- END header -->
<div id="container">
  <div class="two-third">
    <div id="slider3" class="nivoSlider" style="width: 630px; height: 280px"> <a href="#"><img title="Heading Here" src="<?= base_url(); ?>assets/img/demo/slide_11.jpg" alt="" width="630" height="280"></a> <img  src="<?= base_url(); ?>assets/img/demo/slide_21.jpg" alt="" width="630" height="280"> <img  src="<?= base_url(); ?>assets/img/demo/slide_31.jpg" alt="" width="630" height="280"> </div>
    <div style="clear:both"></div>
    <div class="one-third">
      <h2>Photoshoot in Paris</h2>
      <img src="<?= base_url(); ?>assets/img/frontpage_thumb2.jpg" alt="">
      <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Tempore percussus ait est amet consensit cellula rei civibus in modo ad nomine.</p>
      <p style="text-align:right"><a href="#" class="button_small white">Continue Reading &raquo;</a></p>
    </div>
    <div class="one-third last">
      <h2>Studio Photography</h2>
      <img src="<?= base_url(); ?>assets/img/frontpage_thumb3.jpg" alt="">
      <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Tempore percussus ait est amet consensit cellula rei civibus in modo ad nomine.</p>
      <p style="text-align:right"><a href="#" class="button_small white">Continue Reading &raquo;</a></p>
    </div>
    <div class="one-third">
      <h2>Lorem Ipsum</h2>
      <img src="<?= base_url(); ?>assets/img/frontpage_thumb4.jpg" alt="">
      <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Tempore percussus ait est amet consensit cellula rei civibus in modo ad nomine.</p>
      <p style="text-align:right"><a href="#" class="button_small white">Continue Reading &raquo;</a></p>
    </div>
    <div class="one-third last">
      <h2>Tempore Amet</h2>
      <img src="<?= base_url(); ?>assets/img/frontpage_thumb1.jpg" alt="">
      <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Tempore percussus ait est amet consensit cellula rei civibus in modo ad nomine.</p>
      <p style="text-align:right"><a href="#" class="button_small white">Continue Reading &raquo;</a></p>
    </div>
  </div>
  <!-- close two third -->
  <div class="sidebar_right">
    <ul id="tabify_menu" class="menu_tab" style="margin: 0;">
      <li class="active"><a href="#fane1">Articles</a></li>
      <li><a href="#fane2">Reviews</a></li>
      <li><a href="#fane3">Comments</a></li>
    </ul>
    <div id="fane1" class="tab_content">
      <div class="tab_article"> <img src="<?= base_url(); ?>assets/img/thumb1.jpg" alt="">
        <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Perquiramus atque ut casus tui.</p>
      </div>
      <div class="tab_article"> <img src="<?= base_url(); ?>assets/img/thumb2.jpg" alt="">
        <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Perquiramus atque ut casus tui.</p>
      </div>
      <div class="tab_article"> <img src="<?= base_url(); ?>assets/img/thumb3.jpg" alt="">
        <p>Perquiramus atque ut casus tui ex quae ad te ad suis caelo dicit hoc. Perquiramus atque ut casus tui.</p>
      </div>
    </div>
    <div id="fane2" class="tab_content">
      <h3>Tab 2</h3>
      <p>Content 2</p>
    </div>
    <div id="fane3" class="tab_content">
      <h3>Tab 3</h3>
      <p>Content 3</p>
    </div>
    <div style="clear:both"></div>
    <h3>Sponsors</h3>
    <img src="<?= base_url(); ?>assets/img/demo_ad.png" alt="">
    <h3>Sidebar Menu</h3>
    <ul class="sidebar_menu" style="margin:0">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Perquiramus Atque</a></li>
      <li><a href="#">Consensit Cellula</a></li>
      <li><a href="#">Another Link</a></li>
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Perquiramus Atque</a></li>
    </ul>
  </div>
  <!-- end sidebar right -->
  <div style="clear:both; height: 40px"></div>
  <h2>This is what we do best</h2>
  <ul class="ca-menu" style="margin:0">
    <li> <a href="#"> <span class="ca-icon">F</span>
      <div class="ca-content">
        <h2 class="ca-main">Exceptional <br>
          Service</h2>
        <h3 class="ca-sub">Personalized to your needs</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">H</span>
      <div class="ca-content">
        <h2 class="ca-main">Creative <br>
          Storytelling</h2>
        <h3 class="ca-sub">Advanced use of technology</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">N</span>
      <div class="ca-content">
        <h2 class="ca-main">Infographical <br>
          Education</h2>
        <h3 class="ca-sub">Understanding visually</h3>
      </div>
      </a> </li>
    <li> <a href="#"> <span class="ca-icon">K</span>
      <div class="ca-content">
        <h2 class="ca-main">Sophisticated <br>
          Team</h2>
        <h3 class="ca-sub">Professionals in action</h3>
      </div>
      </a> </li>
  </ul>
  <div style="clear:both; height: 40px"></div>
</div>
<!-- end container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
    <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
      Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="<?= base_url(); ?>assets/img/icon_fb.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_twitter.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>