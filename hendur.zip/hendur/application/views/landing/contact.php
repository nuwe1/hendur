<!DOCTYPE HTML>
<head>
<title>Hendur | Contact</title>
<meta charset="utf-8">
<!-- CSS Files -->
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/css/style.css">
<link rel="stylesheet" type="text/css" media="screen" href="<?= base_url(); ?>assets/menu/css/simple_menu.css">
<link rel="stylesheet" href="<?= base_url(); ?>assets/css/nivo-slider.css" type="text/css" media="screen">
<!-- JS Files -->
<script src="<?= base_url(); ?>assets/js/jquery.min.js"></script>
<script src="<?= base_url(); ?>assets/js/custom.js"></script>
<script src="<?= base_url(); ?>assets/js/slides/slides.min.jquery.js"></script>
<script src="<?= base_url(); ?>assets/js/cycle-slider/cycle.js"></script>
<script src="<?= base_url(); ?>assets/js/nivo-slider/jquery.nivo.slider.js"></script>
<script src="<?= base_url(); ?>assets/js/tabify/jquery.tabify.js"></script>
<script src="<?= base_url(); ?>assets/js/prettyPhoto/jquery.prettyPhoto.js"></script>
<script src="<?= base_url(); ?>assets/js/twitter/jquery.tweet.js"></script>
<script src="<?= base_url(); ?>assets/js/scrolltop/scrolltopcontrol.js"></script>
<script src="<?= base_url(); ?>assets/js/portfolio/filterable.js"></script>
<script src="<?= base_url(); ?>assets/js/modernizr/modernizr-2.0.3.js"></script>
<script src="<?= base_url(); ?>assets/js/easing/jquery.easing.1.3.js"></script>
<script src="<?= base_url(); ?>assets/js/kwicks/jquery.kwicks-1.5.1.pack.js"></script>
<script src="<?= base_url(); ?>assets/js/swfobject/swfobject.js"></script>
<!-- FancyBox -->
<link rel="stylesheet" type="text/css" href="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox.css" media="all">
<script src="<?= base_url(); ?>assets/js/fancybox/jquery.fancybox-1.2.1.js"></script>
</head>
<body>
<div class="header">
  <!-- Logo/Title -->
  <div id="site_title"><a href="index.html"> <img src="<?= base_url(); ?>assets/img/logo.png" alt=""></a> </div>
  <!-- Main Menu -->
  <ol id="menu">
    <li><a href="<?=site_url('Welcome/home');?>">Home</a>
      
    </li>
    <li><a href="<?=site_url('Welcome/blog');?>">Blog</a>
    </li>
    <li><a href="<?=site_url('Welcome/about');?>">About</a>   
    </li>
    <li><a href="<?=site_url('Welcome/sponsor');?>">Sponsors</a>   
    </li>
    <li><a href="<?=site_url('Welcome/product');?>">Products</a>   
    </li>
    <li><a href="<?=site_url('Welcome/contact');?>">Contact</a>   
    </li>
    
  </ol>
</div>
<!-- END header -->
<div id="container">
  <h1>Full Width Page</h1>
  <div class="one-half">
    <div class="heading_bg">
      <h2>Contact</h2>
    </div>
    <p><strong>Professional Studios</strong><br>
      NORWAY<br>
      <br>
      Tel: (+47) 99 88 77 66<br>
      mail: mail@studios.com </p>
  </div>
  <div class="one-half last">
    <form action="#" id="contact_form" method="post">
      <fieldset>
        <label>Name <span class="required">*</span></label>
        <input type="text" name="name" id="Myname" value="" class="text requiredField">
      </fieldset>
      <fieldset>
        <label>Email <span class="required">*</span></label>
        <input type="text" name="email" id="myemail" value="" class="text requiredField email">
      </fieldset>
      <fieldset>
        <label>Subject <span class="required">*</span></label>
        <input type="text" name="subject" id="mySubject" value="" class="text requiredField subject">
      </fieldset>
      <fieldset>
        <label>Your Message <span class="required">*</span></label>
        <textarea name="message" id="Mymessage" rows="20" cols="30" class="text requiredField"></textarea>
      </fieldset>
      <fieldset>
        <input name="Mysubmitted" id="Mysubmitted" value="Send Message" class="button white" type="submit">
      </fieldset>
    </form>
    <!--END form ID contact_form -->
  </div>
  <div style="clear:both; height: 40px"></div>
</div>
<!-- close container -->
<div id="footer">
  <!-- First Column -->
  <div class="one-fourth">
    <h3>Useful Links</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Second Column -->
  <div class="one-fourth">
    <h3>Terms</h3>
    <ul class="footer_links">
      <li><a href="#">Lorem Ipsum</a></li>
      <li><a href="#">Ellem Ciet</a></li>
      <li><a href="#">Currivitas</a></li>
      <li><a href="#">Salim Aritu</a></li>
    </ul>
  </div>
  <!-- Third Column -->
  <div class="one-fourth">
    <h3>Information</h3>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit. Praesent sit amet enim id dui tincidunt vestibulum rhoncus a felis.
    <div id="social_icons"> Theme by <a href="http://www.csstemplateheaven.com">CssTemplateHeaven</a><br>
      Photos © <a href="http://dieterschneider.net">Dieter Schneider</a> </div>
  </div>
  <!-- Fourth Column -->
  <div class="one-fourth last">
    <h3>Socialize</h3>
    <img src="<?= base_url(); ?>assets/img/icon_fb.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_twitter.png" alt=""> <img src="<?= base_url(); ?>assets/img/icon_in.png" alt=""> </div>
  <div style="clear:both"></div>
</div>
<!-- END footer -->
</body>
</html>