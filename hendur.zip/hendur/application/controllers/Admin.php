<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	public function index()
	{
		$this->load->view('admin/index');
	}

     public function dashboard()
     {
          $data['title'] = 'Dashboard';

          $this->load->view('admin/includes/header', $data);
          $this->load->view('admin/includes/menu', $data);
          $this->load->view('admin/dashboard', $data);
     }
}

?>
