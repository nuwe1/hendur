<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function index()
	{
		$this->load->view('landing/index');
	}
	public function home()
	{
		$this->load->view('landing/home');
	}
	public function blog()
	{
		$this->load->view('landing/blog');
	}
	public function about()
	{
		$this->load->view('landing/about');
	}
	public function sponsor()
	{
		$this->load->view('landing/sponsor');
	}
	public function product()
	{
		$this->load->view('landing/product');
	}
	public function contact()
	{
		$this->load->view('landing/contact');
	}
}

?>
