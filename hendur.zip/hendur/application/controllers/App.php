<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class App extends CI_Controller {
	public function index()
	{
          $data['title'] = 'Login';
          $this->load->view('app/index', $data);
	}

     public function dashboard()
     {
          $data['title'] = 'Dashboard';

          $this->load->view('app/includes/header', $data);
          $this->load->view('app/includes/menu', $data);
          $this->load->view('app/dashboard', $data);
     }
}

?>
